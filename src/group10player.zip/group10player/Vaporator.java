package group10player;
import battlecode.common.*;

public class Vaporator extends Building {
    public Vaporator(RobotController rc) throws GameActionException {
        super(rc);
    }

    @Override
    public void takeTurn() throws GameActionException {
        super.takeTurn();
    }
}
