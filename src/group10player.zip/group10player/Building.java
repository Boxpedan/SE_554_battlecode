package group10player;

import battlecode.common.*;

//building will extend Robot
public class Building extends Robot{
    public Building(RobotController rc) throws GameActionException{
        super(rc);
    }

    @Override
    public void takeTurn() throws GameActionException{
        super.takeTurn();
    }
}
